#!/usr/bin/python
# -*- coding: utf-8 -*- 
import requests
import json
import sys
import os 
headers = {'Content-Type': 'application/json;charset=utf-8'}
api_url = "https://oapi.dingtalk.com/robot/send?access_token=50f2ea904779b9c2c1237cc28b21ce48a1705ab4a850ab820b5f6a6c965986e0"
def msg(text):
    json_text= {
     "msgtype": "text",
        "text": {
            "content": text
        },
        "at": {
            "atMobiles": [
                "15274865090"
            ],
            "isAtAll": False
        }
    }
    print(requests.post(api_url,json.dumps(json_text),headers=headers).content)
 
if __name__ == '__main__':
    text = sys.argv[1]
    msg(text)
