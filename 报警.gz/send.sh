#!/bin/bash
to=$1
subject=$2
text=$3
curl 'https://oapi.dingtalk.com/robot/send?access_token=50f2ea904779b9c2c1237cc28b21ce48a1705ab4a850ab820b5f6a6c965986e0' \
-H 'Content-Type: application/json' \
-d '
{"msgtype": "text",
"text": {
"content": "'"$text"'"
},
"at":{
"atMobiles": [ "'"$1"'" ],
"isAtAll": false
}
}'
