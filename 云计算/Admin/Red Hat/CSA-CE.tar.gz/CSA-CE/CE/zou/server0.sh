#!/bin/bash
# TsengYia 2016.06.25
#num=$(hostname -s | grep -oE '[0-9]+$')
[ -z "$num" ] && num=0
system1="server${num}"
system2="desktop${num}"
domain="example.com"
ip1="172.25.${num}.11"
ip2="172.25.${num}.10"
> /tmp/pass.rec

PA() {
    	echo -e "\033[32m**********[pass]*********\033[0m"
	return 0   
}
FA() {
    	echo -e "\033[31m**********[fail]**********\033[0m"
	return 1   
}

PASS() {	
	echo "pass" >> /tmp/pass.rec	
	echo -e "\033[32m                                       [PASS]\033[0m"  
}
FAIL() {   
	echo "failed" >> /tmp/pass.rec
	echo -e "\033[31m                                       [FAIL]\033[0m"
}

echo "######## Check-Report for $system1 #######"
echo "*********************************************************************"
echo "01. checking selinux status .... "
getenforce | grep -qw Enforcing && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "getenforce | grep -qw Enforcing----"
getenforce | grep -qw Enforcing && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "02. checking ssh access .... "
grep -qE " *DenyUsers.*\*@(my133.org|172.34.0.)" /etc/ssh/sshd_config || firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" || firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && PASS || FAIL
echo "      -----------------------------          "
echo  'grep -qE " *DenyUsers.*\*@(my133.org|172.34.0.)" /etc/ssh/sshd_config'
grep -qE " *DenyUsers.*\*@(my133.org|172.34.0.)" /etc/ssh/sshd_config && PA || FA
echo  "firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24""
firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" && PA || FA 
echo  "firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24""
firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "03. checking alias .... "
alias qstat &> /dev/null && alias qstat | grep -qE "/bin/ps +-Ao +pid,tt,user,fname,rsz"  && PASS || FAIL

echo "*********************************************************************"
echo  "04. checking firewall configuration .... "
systemctl is-active firewalld &> /dev/null && firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" || firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && firewall-cmd --list-all --zone=trusted  | grep -qw default && firewall-cmd --list-all --zone=trusted  | grep -qw "port=5423:proto=tcp:toport=80" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "---1---"
echo "systemctl is-active firewalld &> /dev/null && firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24""
systemctl is-active firewalld &> /dev/null && firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" && PA ||FA
echo "---2---"
echo "firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && firewall-cmd --list-all --zone=trusted  | grep -qw default && firewall-cmd --list-all --zone=trusted  | grep -qw "port=5423:proto=tcp:toport=80""
firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && firewall-cmd --list-all --zone=trusted  | grep -qw default && firewall-cmd --list-all --zone=trusted  | grep -qw "port=5423:proto=tcp:toport=80" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "05. checking teambridge .. .."
ifconfig team0 2> /dev/null | grep -qw 172.16.3.20 && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "ifconfig team0 2> /dev/null | grep -qw 172.16.3.20"
ifconfig team0 2> /dev/null | grep -qw 172.16.3.20 && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "06. checking ipv6 address .. .. "
ip add list eth0 | grep -qw "2003:ac18::305/64" && ping6 -c3 -i 0.2 -W1 2003:ac18::306 &> /dev/null && PASS || FAIL
echo "      ------------------------------------------------------          "
echo " ip add list eth0 | grep -qw "2003:ac18::305/64" "
ip add list eth0 | grep -qw "2003:ac18::305/64" && PA || FA
echo "ping6 -c3 -i 0.2 -W1 2003:ac18::306 &> /dev/null"
ping6 -c3 -i 0.2 -W1 2003:ac18::306 &> /dev/null && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "07. checking smtp-nullclient mail .. .. "
lab smtp-nullclient grade | grep -q PASS && PASS || FAIL
echo "      ------------------------------------------------------          "
echo  "lab smtp-nullclient grade | grep -q PASS"
lab smtp-nullclient grade | grep -q PASS && PA || FA
echo "Mail Data" | mail -s "Test1" student 2> /dev/null
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "08. checking samba server .. .."
yum -y install cifs-utils samba-client &> /dev/null ; mkdir -p /tmp/mnt ; mount -o username=harry,password=migwhisk //${system1}/common /tmp/mnt &> /dev/null   && PASS || FAIL && umount /tmp/mnt &> /dev/null
echo "      ------------------------------------------------------          "
echo "
yum -y install cifs-utils samba-client &> /dev/null ; 
mkdir -p /tmp/mnt ; 
mount -o username=harry,password=migwhisk //${system1}/common /tmp/mnt &> /dev/null"
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "09. checking multiuser samba .. .. "
getfacl -p /devops 2> /dev/null | grep -q "user:chihiro:rwx" && mount -o username=chihiro,password=atenorth,multiuser,sec=ntlmssp //${system1}/devops /tmp/mnt &> /dev/null && PASS || FAIL && umount /tmp/mnt &> /dev/null
echo "      ------------------------------------------------------          "
echo "getfacl -p /devops 2> /dev/null | grep -q "user:chihiro:rwx""
getfacl -p /devops 2> /dev/null | grep -q "user:chihiro:rwx" && PA || FA
echo "mount -o username=chihiro,password=atenorth,multiuser,sec=ntlmssp //${system1}/devops /tmp/mnt"
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "10. checking NFS server .. .. "
wget http://classroom/pub/keytabs/${system1}.keytab -O /tmp/${system1}.keytab &> /dev/null
diff /etc/krb5.keytab /tmp/${system1}.keytab &> /dev/null && ls -ld /protected/project/ | grep -qw "ldapuser${num} root" && grep -qE "^/protected.*sec=krb5p" /etc/exports && systemctl is-active nfs-secure-server &> /dev/null && systemctl is-active nfs-server &> /dev/null && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "wget http://classroom/pub/keytabs/${system1}.keytab -O /tmp/${system1}.keytab &> /dev/null"
echo "diff /etc/krb5.keytab /tmp/${system1}.keytab &> /dev/null"
diff /etc/krb5.keytab /tmp/${system1}.keytab &> /dev/null && PA || FA
echo "ls -ld /protected/project/ | grep -qw "ldapuser${num} root" "
ls -ld /protected/project/ | grep -qw "ldapuser${num} root"  && PA || FA
echo "grep -qE "^/protected.*sec=krb5p" /etc/exports" 
grep -qE "^/protected.*sec=krb5p" /etc/exports && PA || FA
echo "systemctl is-active nfs-secure-server &> /dev/null"
systemctl is-active nfs-secure-server &> /dev/null && PA || FA
echo "systemctl is-active nfs-server &> /dev/null"
systemctl is-active nfs-server &> /dev/null && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "11. checking NFS client .. .. "
mkdir -p /tmp/mnt ; systemctl restart nfs-secure &> /dev/null && showmount -e ${system1} 2> /dev/null | grep -qw protected && mount -o v4,sec=krb5p ${system1}:/protected /tmp/mnt &> /dev/null  && umount /tmp/mnt &> /dev/null && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "mkdir -p /tmp/mnt ; systemctl restart nfs-secure &> /dev/null" 
mkdir -p /tmp/mnt ;
systemctl restart nfs-secure &> /dev/null && PA || FA
echo "showmount -e ${system1} 2> /dev/null | grep -qw protected"
showmount -e ${system1} 2> /dev/null | grep -qw protected && PA || FA
echo "mount -o v4,sec=krb5p ${system1}:/protected /tmp/mnt &> /dev/null"
echo $?
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "12. checking web-default .. .. "
yum -y install elinks &> /dev/null ; elinks -dump http://${system1}.${domain} 2> /dev/null| grep -qw "Default Site." && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "yum -y install elinks &> /dev/null ; elinks -dump http://${system1}.${domain} 2> /dev/null| grep -qw "Default Site.""
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "13. checking web-HTTPS .. .. "
netstat -anpt | grep -qw :443 && wget https://${system1}.${domain} 2>&1 | grep -q "North Carolina" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "netstat -anpt | grep -qw :443"
netstat -anpt | grep -qw :443 && PA || FA
echo "wget https://${system1}.${domain} 2>&1 | grep -q "North Carolina""
wget https://${system1}.${domain} 2>&1 | grep -q "North Carolina" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "14. checking web-virtualhost .. .. "
elinks -dump http://www${num}.${domain} 2> /dev/null | grep -qw "Virtual Site." && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "elinks -dump http://www${num}.${domain} 2> /dev/null | grep -qw "Virtual Site.""
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "15. checking web-access controll .. .. "
ifconfig lo:0 172.${num}.${num}.1
elinks -dump http://${system1}.${domain}/private 2> /dev/null | grep -qw "Private Site." && elinks -dump http://172.${num}.${num}.1/private | grep -qw "Forbidden" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "elinks -dump http://${system1}.${domain}/private 2> /dev/null | grep -qw "Private Site." "
elinks -dump http://${system1}.${domain}/private 2> /dev/null | grep -qw "Private Site."  && PA || FA
echo "elinks -dump http://172.${num}.${num}.1/private | grep -qw "Forbidden""
elinks -dump http://172.${num}.${num}.1/private | grep -qw "Forbidden" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "16. checking web-dynamic WSGI .. .. "
netstat -antpu | grep -qw :8909 && elinks -dump http://webapp${num}.${domain}:8909 2> /dev/null | grep -qw "UNIX EPOCH time is now:" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "netstat -antpu | grep -qw :8909"
netstat -antpu | grep -qw :8909 && PA || FA
echo "elinks -dump http://webapp${num}.${domain}:8909 2> /dev/null | grep -qw "UNIX EPOCH time is now:""
elinks -dump http://webapp${num}.${domain}:8909 2> /dev/null | grep -qw "UNIX EPOCH time is now:" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "17. checking shell script .. .. "
[ -x /root/foo.sh ] && /root/foo.sh 2>&1 | grep -qEw  "/root/foo.sh ?redhat|fedora" && /root/foo.sh redhat | grep -qw fedora && /root/foo.sh fedora | grep -qw redhat && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "[ -x /root/foo.sh ]" 
[ -x /root/foo.sh ] && PA || FA
echo '/root/foo.sh 2>&1 | grep -qEw  "/root/foo.sh ?redhat|fedora" '
/root/foo.sh 2>&1 | grep -qEw  "/root/foo.sh ?redhat|fedora" && PA || FA
echo "/root/foo.sh redhat | grep -qw fedora"
/root/foo.sh redhat | grep -qw fedora && PA || FA
echo " /root/foo.sh fedora | grep -qw redhat"
 /root/foo.sh fedora | grep -qw redhat && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "18. checking batch users .. .. "
echo -e "chk01\nchk02" > /tmp/u001.txt ; [ -x /root/batchusers ] && /root/batchusers | grep -qEw "Usage: ?/root/batchusers <userfile>" && /root/batchusers /tmp/u002.txt | grep -qw "Input file not found" && /root/batchusers /tmp/u001.txt &> /dev/null && id chk01 &> /dev/null && grep -w chk01 /etc/passwd | grep -qw /bin/false && PASS || FAIL ; userdel -r chk01 2> /dev/null && userdel -r chk02 2> /dev/null
echo "      ------------------------------------------------------          "
echo "echo -e "chk01\nchk02" > /tmp/u001.txt ; [ -x /root/batchusers ]"
[ -x /root/batchusers ]  && PA || FA
echo "/root/batchusers | grep -qEw "Usage: ?/root/batchusers <userfile>""
/root/batchusers | grep -qEw "Usage: ?/root/batchusers <userfile>" && PA || FA
echo "/root/batchusers /tmp/u002.txt | grep -qw "Input file not found""
/root/batchusers /tmp/u002.txt | grep -qw "Input file not found"　&& PA || FA
echo "/root/batchusers /tmp/u001.txt &> /dev/null"
/root/batchusers /tmp/u001.txt &> /dev/null && PA || FA
echo "id chk01 &> /dev/null"
id chk01 &> /dev/null && PA || FA
echo "grep -w chk01 /etc/passwd | grep -qw /bin/false"
grep -w chk01 /etc/passwd | grep -qw /bin/false && PA || FA
userdel -r chk01 2> /dev/null && userdel -r chk02 2> /dev/null
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "19. checking iSCSI server .. .. "
targetcli ls 2> /dev/null | grep -qEw "iqn.2016-02.com.example:${system1}.*TPGs:.*" && targetcli ls 2> /dev/null | grep -qEw "iqn.2016-02.com.example:${system2}.*LUNs:.*" && targetcli ls | grep -qwE "$ip1:3260|0.0.0.0:3260" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "targetcli ls 2> /dev/null | grep -qEw "iqn.2016-02.com.example:${system1}.*TPGs:.*" "
targetcli ls 2> /dev/null | grep -qEw "iqn.2016-02.com.example:${system1}.*TPGs:.*"  && PA || FA
echo "targetcli ls 2> /dev/null | grep -qEw "iqn.2016-02.com.example:${system2}.*LUNs:.*""
targetcli ls 2> /dev/null | grep -qEw "iqn.2016-02.com.example:${system2}.*LUNs:.*" && PA || FA
echo "ip1=$ip1"
echo "targetcli ls | grep -qwE " "$ip1:3260|0.0.0.0:3260"
targetcli ls | grep -qwE "$ip1:3260|0.0.0.0:3260" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "20. checking iSCSI client .. .. "
echo "skiped"

echo "*********************************************************************"
echo  "21. checking MariaDB deployment .. .. "
mysql -u root -patenorth -e 'show databases;' &> /dev/null && mysql -u Raikon -patenorth -e 'use Contacts; show tables;' 2> /dev/null | grep -qw location && mysql -u root -patenorth -h ${system1} -e 'show databases;' 2>&1 | grep -qw ERROR && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "mysql -u root -patenorth -e 'show databases;' &> /dev/null"
mysql -u root -patenorth -e 'show databases;' &> /dev/null && PA || FA
echo "mysql -u Raikon -patenorth -e 'use Contacts; show tables;' 2> /dev/null | grep -qw location "
mysql -u Raikon -patenorth -e 'use Contacts; show tables;' 2> /dev/null | grep -qw location && PA || FA
echo "mysql -u root -patenorth -h ${system1} -e 'show databases;' 2>&1 | grep -qw ERROR"
mysql -u root -patenorth -h ${system1} -e 'show databases;' 2>&1 | grep -qw ERROR && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo  "22. checking MariaDB select .. .. "
echo "skiped"

echo "######## ######## ########  ######## ######## #######"
