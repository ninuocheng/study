#!/bin/bash
# TsengYia 2016.06.25
num=$(hostname -s | grep -oE '[0-9]+$')
[ -z "$num" ] && num=0
system1="server${num}"
system2="desktop${num}"
domain="example.com"
ip1="172.25.${num}.11"
ip2="172.25.${num}.10"
> /tmp/pass.rec

PA() {
    	echo -e "\033[32m**********[pass]*********\033[0m"
	return 0   
}
FA() {
    	echo -e "\033[31m**********[fail]**********\033[0m"
	return 1   
}

PASS() {	
	echo "pass" >> /tmp/pass.rec	
	echo -e "\033[32m                                       [PASS]\033[0m"  
}
FAIL() {   
	echo "failed" >> /tmp/pass.rec
	echo -e "\033[31m                                       [FAIL]\033[0m"
}


echo "######## Check-Report for $system2 #######"
echo "*********************************************************************"
echo "01. checking selinux status .... "
getenforce | grep -qw Enforcing && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "getenforce | grep -qw Enforcing"
echo "      ------------------------------------------------------          "
echo "*********************************************************************"
echo "02. checking ssh access .... "
grep -qE " *DenyUsers.*\*@(my133.org|172.34.0.)" /etc/ssh/sshd_config || firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" || firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo 'grep -qE " *DenyUsers.*\*@(my133.org|172.34.0.)" /etc/ssh/sshd_config'
grep -qE " *DenyUsers.*\*@(my133.org|172.34.0.)" /etc/ssh/sshd_config && PA || FA
echo "firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24""
firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" && PA || FA
echo "firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24""
firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "03. checking alias .... "
alias qstat 2> /dev/null | grep -qE "/bin/ps +-Ao +pid,tt,user,fname,rsz" && PASS || FAIL

echo "*********************************************************************"
echo "04. checking firewall configuration .... "
systemctl is-active firewalld &> /dev/null && firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" || firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && firewall-cmd --list-all --zone=trusted  | grep -qw default && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "systemctl is-active firewalld &> /dev/null"
systemctl is-active firewalld &> /dev/null && PA || FA
echo "firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24""
firewall-cmd --list-all --zone=block 2> /dev/null | grep -qw "172.34.0.0/24" && PA || FA
echo "firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24""
firewall-cmd --list-all --zone=drop 2> /dev/null | grep -qw "172.34.0.0/24" && PA || FA
echo "firewall-cmd --list-all --zone=trusted  | grep -qw default"
firewall-cmd --list-all --zone=trusted  | grep -qw default && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "05. checking teambridge .. .."
ifconfig team0 2> /dev/null | grep -qw 172.16.3.25 && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "ifconfig team0 2> /dev/null | grep -qw 172.16.3.25"
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "06. checking ipv6 address .. .. "
ip add list eth0 | grep -qw "2003:ac18::306/64" && ping6 -c3 -i 0.2 -W1 2003:ac18::305 &> /dev/null && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "ip add list eth0 | grep -qw "2003:ac18::306/64""
ip add list eth0 | grep -qw "2003:ac18::306/64" && PA || FA
echo "ping6 -c3 -i 0.2 -W1 2003:ac18::305 &> /dev/null"
ping6 -c3 -i 0.2 -W1 2003:ac18::305 &> /dev/null && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "07. checking smtp-nullclient mail .. .. "
grep -qw "Subject: Test1" /var/mail/student && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "grep -qw "Subject: Test1" /var/mail/student"
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "08. checking samba server .. .."
mkdir -p /tmp/mnt ; mount -o username=harry,password=migwhisk //${system1}/common /tmp/mnt &> /dev/null && PASS && umount /tmp/mnt || FAIL
echo "      ------------------------------------------------------          "
echo "mkdir -p /tmp/mnt"
echo "system1=$system1"
echo 'mount -o username=harry,password=migwhisk //${system1}/common /tmp/mnt &> /dev/null'
mount -o username=harry,password=migwhisk //${system1}/common /tmp/mnt &> /dev/null && PA && umount /tmp/mnt || FA
echo "      ------------------------------------------------------          "


echo "*********************************************************************"
echo "09. checking multiuser samba .. .. "
mount | grep -qE "^//(${system1}|${ip1}).*/devops on /mnt/dev .*sec=ntlmssp.*" && mount -o username=chihiro,password=atenorth,multiuser,sec=ntlmssp //${system1}/devops /tmp/mnt && PASS && umount /tmp/mnt || FAIL
echo "      ------------------------------------------------------          "
echo "system1=$system1  ip1=$ip1"
echo 'mount | grep -qE "^//(${system1}|${ip1}).*/devops on /mnt/dev .*sec=ntlmssp.*"'
mount | grep -qE "^//(${system1}|${ip1}).*/devops on /mnt/dev .*sec=ntlmssp.*" && PA || FA
echo 'mount -o username=chihiro,password=atenorth,multiuser,sec=ntlmssp //${system1}/devops /tmp/mnt'
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "10. checking NFS server .. .."
showmount -e ${system1} 2> /dev/null | grep -qw "^/public" && showmount -e ${system1} 2> /dev/null | grep -qw "^/protected"  && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "system1=$system1"
echo 'showmount -e ${system1} 2> /dev/null | grep -qw "^/public"'
showmount -e ${system1} 2> /dev/null | grep -qw "^/public" && PA || FA
echo 'showmount -e ${system1} 2> /dev/null | grep -qw "^/protected"'
showmount -e ${system1} 2> /dev/null | grep -qw "^/protected" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "11. checking NFS client .. .. "
wget http://classroom/pub/keytabs/${system2}.keytab -O /tmp/${system2}.keytab &> /dev/null
diff /etc/krb5.keytab /tmp/${system2}.keytab &> /dev/null && systemctl is-active nfs-secure &> /dev/null && mount | grep -qE "^(${system1}|${ip1}).*/public .*/mnt/nfsmount .*" && mount | grep -qE "^(${system1}|${ip1}).*/protected .*/mnt/nfssecure.*" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "system2=$system2"
echo 'wget http://classroom/pub/keytabs/${system2}.keytab -O /tmp/${system2}.keytab &> /dev/null'
diff /etc/krb5.keytab /tmp/${system2}.keytab &> /dev/null && PA || FA
echo "systemctl is-active nfs-secure &> /dev/null"
systemctl is-active nfs-secure &> /dev/null && PA || FA
echo "system1=$system1 ip1=$ip1"
echo 'mount | grep -qE "^(${system1}|${ip1}).*/public .*/mnt/nfsmount .*"'
mount | grep -qE "^(${system1}|${ip1}).*/public .*/mnt/nfsmount .*" && PA || FA
echo 'mount | grep -qE "^(${system1}|${ip1}).*/protected .*/mnt/nfssecure.*"'
mount | grep -qE "^(${system1}|${ip1}).*/protected .*/mnt/nfssecure.*" && PA || FA
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "12. checking web-default .. .. "
yum -y install elinks &> /dev/null ; elinks -dump http://${system1}.${domain} 2> /dev/null | grep -qw "Default Site." && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "system1=$system1 domain=$domain "
echo 'elinks -dump http://${system1}.${domain} 2> /dev/null | grep -qw "Default Site."'
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "13. checking web-HTTPS .. .. "
wget https://${system1}.${domain} 2>&1 | grep -q "North Carolina" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "system1=$system1 domain=$domain "
echo 'wget https://${system1}.${domain} 2>&1 | grep -q "North Carolina"'
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "14. checking web-virtualhost .. .. "
elinks -dump http://www${num}.${domain} 2> /dev/null | grep -qw "Virtual Site." && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "num=$num domain=$domain"
echo 'elinks -dump http://www${num}.${domain} 2> /dev/null | grep -qw "Virtual Site."'
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "15. checking web-access controll .. .. "
elinks -dump http://${system1}.${domain}/private 2> /dev/null | grep -qw "Forbidden" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "system1=$system1 domain=$domain"
echo 'elinks -dump http://${system1}.${domain}/private 2> /dev/null | grep -qw "Forbidden"'
echo "      ------------------------------------------------------          "

echo "*********************************************************************"
echo "16. checking web-dynamic WSGI .. .. "
elinks -dump http://webapp${num}.${domain}:8909 2> /dev/null | grep -qw "UNIX EPOCH time is now:" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "num=$num domain=$domain"
echo 'elinks -dump http://webapp${num}.${domain}:8909 2> /dev/null | grep -qw "UNIX EPOCH time is now:" '
echo "      ------------------------------------------------------          "


echo "17. checking shell script .. .. "
echo "skiped"
echo "18. checking batch users .. .. "
echo "skiped"
echo "19. checking iSCSI server .. .. "
echo "skiped"

echo "20. checking iSCSI client .. .. "
df -h /mnt/data 2> /dev/null | grep -qE "^/dev/sda1 +2.0G +" && PASS || FAIL
echo "      ------------------------------------------------------          "
echo "df -h /mnt/data 2> /dev/null | grep -qE "^/dev/sda1 +2.0G +""
echo "      ------------------------------------------------------          "

echo "21. checking MariaDB deployment .. .. "
echo "skiped"
echo "22. checking MariaDB select .. .. "
echo "skiped"
echo "######## ######## ########  ######## ######## #######"
